//
//  ChartsRealm.h
//  Charts
//
//  Copyright 2015 Daniel Cohen Gindi & Philipp Jahoda
//  A port of MPAndroidChart for iOS
//  Licensed under Apache License 2.0
//
//  https://github.com/danielgindi/Charts
//

#import <Foundation/Foundation.h>

//! Project version number for ChartsRealm.
FOUNDATION_EXPORT double ChartsRealmVersionNumber;

//! Project version string for ChartsRealm.
FOUNDATION_EXPORT const unsigned char ChartsRealmVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ChartsRealm/PublicHeader.h>


