//
//  SlideNavigationViewController.h
//  CostList
//
//  
//

#import <UIKit/UIKit.h>

@interface SlideNavigationViewController : UINavigationController
@property (assign, nonatomic, getter=isLeftMenuVisible) BOOL isVisible;
@end
