//
//  CostItem+CoreDataProperties.m
//  CostList
//
//  
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "CostItem+CoreDataProperties.h"

@implementation CostItem (CoreDataProperties)

@dynamic category;
@dynamic categoryName;
@dynamic comment;
@dynamic date;
@dynamic location;
@dynamic money;
@dynamic photoId;
@dynamic createTime;

@end
