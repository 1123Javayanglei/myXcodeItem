//
//  CLLockInfoView.h
//  CoreLock
//
//  
//  仅仅是做展示用

#import <UIKit/UIKit.h>

@interface CLLockInfoView : UIView

@end
