//
//  CLLockMainView.h
//  CoreLock
//
// 
//

#import <UIKit/UIKit.h>

@interface CLLockMainView : UIView

@end
