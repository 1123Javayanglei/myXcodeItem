//
//  CLLockNavVC.h
//  CoreLock
//
//  
//

#import <UIKit/UIKit.h>

@interface CLLockNavVC : UINavigationController

@end
