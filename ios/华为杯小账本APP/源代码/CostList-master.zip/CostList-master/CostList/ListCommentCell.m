//
//  ListCommentCell.m
//  CostList
//
//  Created by 许德鸿 on 16/9/10.
//  Copyright © 2016年 XuDeHong. All rights reserved.
//

#import "ListCommentCell.h"

@implementation ListCommentCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
