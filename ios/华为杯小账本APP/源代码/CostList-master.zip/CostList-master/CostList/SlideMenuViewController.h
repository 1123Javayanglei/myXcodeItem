//
//  SlideMenuViewController.h
//  CostList
//
//
//

#import <UIKit/UIKit.h>

@interface SlideMenuViewController : UITableViewController

@end
