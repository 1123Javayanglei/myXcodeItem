//
//  ListCell.m
//  CostList
//
//  Created by 许德鸿 on 16/9/8.
//  Copyright © 2016年 XuDeHong. All rights reserved.
//

#import "ListCell.h"


@implementation ListCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
